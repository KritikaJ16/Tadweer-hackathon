import React, { useState } from "react";
import { Sparkles, ChevronRight } from "lucide-react";

/**
 * RoadmapGenerator — standalone version of Desert Pulse's launch-plan builder.
 *
 * Given a community-validated opportunity, it produces a phased 30-day roadmap
 * (validate -> set up -> launch -> grow) with concrete first steps and rough
 * AED cost estimates. This is the deterministic, offline template version.
 *
 * To make it AI-powered like the integrated app, replace buildRoadmap() with a
 * call to your Pulse endpoint (see callPulse in App.jsx) and render the reply.
 */

const T = {
  ink: "#2B2118",
  oasis: "#1F7A6C",
  dune: "#C98A4B",
  line: "rgba(43,33,24,0.12)",
};

const OPPORTUNITIES = [
  { id: "evening-cafe", name: "Evening Cafe", startCost: "15,000–35,000" },
  { id: "home-bakery", name: "Home Bakery", startCost: "3,000–8,000" },
  { id: "home-tutoring", name: "Home Tutoring", startCost: "500–2,000" },
  { id: "camel-vet", name: "Camel Veterinary Service", startCost: "20,000–50,000" },
  { id: "date-marketplace", name: "Local Date Marketplace", startCost: "5,000–12,000" },
  { id: "equipment-rental", name: "Farm Equipment Rental", startCost: "40,000–90,000" },
];

function buildRoadmap(opp) {
  return [
    {
      phase: "Days 1–7 · Validate",
      steps: [
        `Talk to 10 residents who said they want ${opp.name.toLowerCase()} and confirm they'd pay.`,
        "Note the price they expect and how often they'd buy.",
        "Pick a single, specific first offer rather than trying to do everything.",
      ],
    },
    {
      phase: "Days 8–16 · Set up",
      steps: [
        `Budget for startup costs (rough estimate: AED ${opp.startCost}).`,
        "Check licensing basics with the Department of Economic Development.",
        "Line up your first supplier or the equipment you need.",
      ],
    },
    {
      phase: "Days 17–24 · Launch",
      steps: [
        "Open to a small group first (friends, neighbours, a single street).",
        "Create a simple WhatsApp / Instagram presence with photos and a price list.",
        "Ask every first customer for a short testimonial.",
      ],
    },
    {
      phase: "Days 25–30 · Grow",
      steps: [
        "Review what sold and what didn't; drop the weak offer.",
        "Reinvest early profit into the one thing customers asked for most.",
        "Set a simple weekly target and track it.",
      ],
    },
  ];
}

export default function RoadmapGenerator() {
  const [oppId, setOppId] = useState(OPPORTUNITIES[0].id);
  const [plan, setPlan] = useState(null);
  const [busy, setBusy] = useState(false);

  const generate = () => {
    const opp = OPPORTUNITIES.find((o) => o.id === oppId);
    setBusy(true);
    // Simulate work; swap for an async Pulse call to make it AI-generated.
    setTimeout(() => {
      setPlan({ opp, phases: buildRoadmap(opp) });
      setBusy(false);
    }, 350);
  };

  return (
    <section style={S.wrap}>
      <div style={S.eyebrow}>From opportunity to action</div>
      <h2 style={S.h2}>Generate a 30-day launch roadmap</h2>
      <p style={S.sub}>
        Pick a community-validated opportunity and get a phased plan with first
        steps and rough cost estimates.
      </p>

      <div style={S.controls}>
        <select style={S.select} value={oppId} onChange={(e) => setOppId(e.target.value)}>
          {OPPORTUNITIES.map((o) => (
            <option key={o.id} value={o.id}>
              {o.name}
            </option>
          ))}
        </select>
        <button style={S.btn} onClick={generate} disabled={busy}>
          <Sparkles size={16} /> {busy ? "Building…" : "Generate roadmap"}
        </button>
      </div>

      {plan && (
        <div style={S.plan}>
          <h3 style={S.planTitle}>{plan.opp.name}</h3>
          <div style={S.estimate}>Estimated startup cost: AED {plan.opp.startCost}</div>
          {plan.phases.map((p, i) => (
            <div key={i} style={S.phase}>
              <div style={S.phaseLabel}>{p.phase}</div>
              <ul style={S.list}>
                {p.steps.map((s, j) => (
                  <li key={j} style={S.step}>
                    <ChevronRight size={14} color={T.oasis} style={{ flexShrink: 0, marginTop: 4 }} />
                    <span>{s}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
          <p style={S.disclaimer}>
            Figures are rough estimates for the Al Ain region. Confirm licensing,
            fees, and taxes with the relevant UAE authority before committing.
          </p>
        </div>
      )}
    </section>
  );
}

const S = {
  wrap: { maxWidth: 680, margin: "0 auto", padding: "40px 20px", color: T.ink },
  eyebrow: {
    fontFamily: "'JetBrains Mono', monospace",
    fontSize: "0.72rem",
    textTransform: "uppercase",
    letterSpacing: "0.12em",
    color: T.dune,
    marginBottom: 8,
  },
  h2: { fontFamily: "'Fraunces', serif", fontSize: "1.9rem", margin: "0 0 6px" },
  sub: { color: "rgba(43,33,24,0.62)", lineHeight: 1.55, margin: "0 0 24px", maxWidth: 560 },
  controls: { display: "flex", gap: 10, flexWrap: "wrap" },
  select: {
    flex: 1,
    minWidth: 200,
    border: `1.5px solid ${T.line}`,
    borderRadius: 12,
    padding: "11px 14px",
    fontFamily: "inherit",
    fontSize: "0.95rem",
    background: "#fff",
    color: T.ink,
  },
  btn: {
    display: "inline-flex",
    alignItems: "center",
    gap: 8,
    background: `linear-gradient(135deg, ${T.dune}, #E3A857)`,
    color: T.ink,
    fontWeight: 600,
    border: "none",
    borderRadius: 999,
    padding: "12px 20px",
    cursor: "pointer",
  },
  plan: {
    marginTop: 24,
    background: "rgba(255,255,255,0.62)",
    border: `1px solid ${T.line}`,
    borderRadius: 20,
    padding: 24,
  },
  planTitle: { fontFamily: "'Fraunces', serif", fontSize: "1.5rem", margin: "0 0 4px" },
  estimate: {
    fontFamily: "'JetBrains Mono', monospace",
    fontSize: "0.82rem",
    color: T.dune,
    marginBottom: 18,
  },
  phase: { marginBottom: 18 },
  phaseLabel: {
    fontFamily: "'JetBrains Mono', monospace",
    fontSize: "0.78rem",
    textTransform: "uppercase",
    letterSpacing: "0.08em",
    color: T.oasis,
    marginBottom: 8,
  },
  list: { listStyle: "none", margin: 0, padding: 0, display: "flex", flexDirection: "column", gap: 8 },
  step: { display: "flex", gap: 8, fontSize: "0.94rem", lineHeight: 1.5 },
  disclaimer: {
    fontSize: "0.8rem",
    color: "rgba(43,33,24,0.6)",
    lineHeight: 1.5,
    marginTop: 12,
    borderTop: `1px solid ${T.line}`,
    paddingTop: 12,
  },
};
